# Dataset validation report

Generated from the live local MySQL database on 2026-10-18.

The staged import has been applied to this local database. All seven companion metadata tables contain the expected rows; no deficiency, symptom, association, food, or weight conflicts were found. Existing food text and symptom weights remain unchanged. User and analysis row counts were unchanged by the import.

## Structural checks

| Dataset | Rows | Primary/logical key check | Foreign-key check |
|---|---:|---|---|
| Deficiency master | 20 | 20 unique deficiency IDs | Not applicable |
| Symptom master | 20 | 20 unique symptom IDs | Not applicable |
| Deficiency-symptom mappings | 48 | No duplicate `(deficiency_id, symptom_id)` pairs found | All deficiency and symptom IDs resolve |
| Food recommendations | 85 | No duplicate `(deficiency_id, normalized food_name)` pairs found | All deficiency IDs resolve |
| Gene associations | 5 | 5 unique association IDs | All deficiency IDs resolve |
| Protein associations | 5 | 5 unique association IDs | All deficiency IDs resolve |
| Pathway associations | 4 | 4 unique association IDs | All deficiency IDs resolve |
| Dataset sources | 38 | 38 unique source IDs, with per-record NCBI, UniProt, and local Reactome-label records | Not applicable |

All current food records have nonblank food names, benefits, and cautions. The deficiency names and IDs correspond to the existing database. The database currently has 20 symptom labels; symptom descriptions in this export are cautious editorial glosses, not quotations from a symptom-specific medical reference.

## Scientific/source review status

- The nutrient fact-sheet URL pattern follows NIH ODS conventions, but requests to ODS pages returned HTTP 403 in the research environment. Individual page availability, contents, and claim-level support therefore remain **unverified in this run**. Check each fact sheet manually before relying on the content.
- The local deficiency-symptom scores were exported unchanged. The weights are project-specific rules, have not been validated, and are not clinical probabilities. The `evidence_note` column explicitly warns that a nutrient fact sheet does not validate an individual symptom mapping.
- The food records are existing project text. No FoodData Central record IDs, composition values, or serving amounts are asserted. Food rows need human source review before being described as fully verified recommendations.
- Existing NCBI gene and UniProt accession identifiers are retained. The associations describe molecular context and must not be represented as genes causing dietary deficiency.
- Reactome pathway IDs are blank because an exact name-to-ID match was not verified. Do not infer stable pathway IDs from generic labels.
- Release/version details are set to `Unknown` when not established. The source file records access date and license caveats rather than inventing values.

## Source and license inventory

- **USDA FoodData Central**: its official About page states that FDC data are public domain under CC0 1.0 and requests attribution. No quantitative FDC data were imported in this package.
- **NCBI/NLM**: the official NCBI policy states that NCBI places no restrictions on molecular database data, while submitter and third-party rights may still apply. Gene record content should be checked for such notices.
- **Reactome**: its official license page says Reactome database data are CC0; pathway illustrations are CC BY 4.0; software and other materials can have different terms.
- **MedlinePlus/NLM**: U.S. government-created NLM content is public domain, with possible third-party copyright exceptions. The symptom CSV uses a general entry point, not copied article text.
- **NIH Office of Dietary Supplements**: no page-specific license determination was made; the inventory marks this as unknown and calls for review of notices and third-party content.
- **UniProt**: no license assertion is made in this export; verify the current UniProtKB license and attribution terms before redistribution.
- **Local DefiMap data**: the project owner has not specified a reuse license.

## Known schema mismatches

The requested CSVs contain provenance and explanatory fields absent from the live MySQL tables:

| Current table | Existing fields usable | Requested fields not currently present |
|---|---|---|
| `deficiency_master` | `deficiency_id`, `deficiency_name`, `description` | `related_nutrient`, `source_url` |
| `symptom_master` | `symptom_id`, `symptom_name` | `description`, `source_url` |
| `deficiency_symptoms` | `deficiency_id`, `symptom_id`, `weight` | `evidence_note`, `source_url`; no composite uniqueness or FKs are enforced |
| `food_recommendations` | `deficiency_id`, `food_name`, `benefits`, `avoid_food` | `nutrient_name`, `source_url`; `benefit` maps to `benefits`, `caution` maps to `avoid_food` |
| `gene_associations` | `id`, `deficiency_id`, `gene_symbol`, `gene_name`, `ncbi_gene_id` | `association_description`, `source_url`; `association_id` maps to `id`, `gene_id` maps to `ncbi_gene_id` |
| `protein_associations` | `id`, `deficiency_id`, `protein_name`, `uniprot_accession` | `protein_function`, `association_description`, `source_url`; `association_id` maps to `id` |
| `pathway_associations` | `id`, `deficiency_id`, `pathway_name` | `pathway_id`, `pathway_description`, `source_url`; `association_id` maps to `id` |
| No current table | — | `dataset_sources` |

`schema_and_import.sql` creates additive staging and metadata tables without dropping or overwriting the application's live data tables.
