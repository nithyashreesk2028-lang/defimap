# DefiMap integrated datasets

Generated from the live `defimap` database by `generate_datasets.php`. The CSVs are UTF-8 with a byte-order mark for common spreadsheet compatibility. They are exports of the existing project records plus explicitly labeled explanatory metadata; they are not a clinical reference standard.

## CSV columns

| Dataset | Column | CSV type | Meaning |
|---|---|---|---|
| `deficiency_master.csv` | `deficiency_id` | integer | Existing primary key from `deficiency_master`. |
| | `deficiency_name` | text | Existing category name. |
| | `description` | text | Existing database description; blank source descriptions remain blank if present. |
| | `related_nutrient` | text | Nutrient label corresponding to the existing category. |
| | `source_url` | URL/text | NIH ODS health-professional fact-sheet URL for background. The target pages returned HTTP 403 in this collection run, so page content and each individual claim were not verified here. |
| `symptom_master.csv` | `symptom_id` | integer | Existing primary key from `symptom_master`. |
| | `symptom_name` | text | Existing symptom label. |
| | `description` | text | Cautious, plain-language gloss; symptoms are nonspecific and not diagnoses. |
| | `source_url` | URL/text | MedlinePlus symptoms entry point, not a claim-specific article citation. |
| `deficiency_symptoms.csv` | `deficiency_id` | integer | Foreign-key value for `deficiency_master.deficiency_id`. |
| | `symptom_id` | integer | Foreign-key value for `symptom_master.symptom_id`. |
| | `weight` | integer | Existing DefiMap project rule weight, exported unchanged. It is not a probability, clinical severity, or validated diagnostic score. |
| | `evidence_note` | text | Explicitly states that the legacy rule has not been independently validated; the linked ODS page is background only. |
| | `source_url` | URL/text | ODS background page for the mapped nutrient; it does not substantiate the individual pair. |
| `food_recommendations.csv` | `deficiency_id` | integer | Foreign-key value for `deficiency_master.deficiency_id`. |
| | `food_name` | text | Existing food recommendation name. |
| | `nutrient_name` | text | Nutrient label for the deficiency category. |
| | `benefit` | text | Existing `food_recommendations.benefits` content. |
| | `caution` | text | Existing `food_recommendations.avoid_food` content. This is a caution field, not an instruction that every person must avoid the food. |
| | `source_url` | URL/text | ODS background page for the nutrient. The data contains no FoodData Central IDs, nutrient quantities, or serving sizes. |
| `gene_associations.csv` | `association_id` | integer | Existing `gene_associations.id`; preserve as the row key when importing this snapshot. |
| | `deficiency_id` | integer | Foreign-key value for `deficiency_master.deficiency_id`. |
| | `gene_symbol` | text | Existing gene symbol. |
| | `gene_id` | integer/text | Existing NCBI Gene identifier (`ncbi_gene_id`). |
| | `gene_name` | text | Existing gene name. |
| | `association_description` | text | Biological context. It does not claim that a gene causes dietary deficiency. |
| | `source_url` | URL/text | NCBI Gene record URL constructed from the existing numeric identifier. |
| `protein_associations.csv` | `association_id` | integer | Existing `protein_associations.id`; preserve as the row key when importing this snapshot. |
| | `deficiency_id` | integer | Foreign-key value for `deficiency_master.deficiency_id`. |
| | `protein_name` | text | Protein label. |
| | `uniprot_accession` | text | Existing UniProt accession. |
| | `protein_function` | text | Brief biological function context. |
| | `association_description` | text | Explains the indirect iron-physiology relationship; not a diagnosis or causal claim. |
| | `source_url` | URL/text | UniProt accession URL. |
| `pathway_associations.csv` | `association_id` | integer | Existing `pathway_associations.id`; preserve as the row key when importing this snapshot. |
| | `deficiency_id` | integer | Foreign-key value for `deficiency_master.deficiency_id`. |
| | `pathway_name` | text | Existing local pathway label. |
| | `pathway_id` | text | Blank where a Reactome identifier could not be confidently verified; do not fill by guessing. |
| | `pathway_description` | text | Flags existing labels whose exact Reactome mapping remains unresolved. |
| | `source_url` | URL/text | Reactome entry point; it is not evidence that the local label has a specific Reactome ID. |
| `dataset_sources.csv` | `source_id` | integer | Primary key for a provenance record in the new `dataset_sources` table. |
| | `dataset_name` | text | Dataset or data group to which the source record relates. |
| | `organization` | text | Source organization or local project database. |
| | `source_url` | URL/text | Source or record entry-point URL; blank only when no web URL exists. |
| | `record_identifier` | text | Source record, collection, or scope identifier. |
| | `version_or_release` | text | Source release when known; otherwise `Unknown`. |
| | `access_date` | ISO date | Date used for this source inventory: `2026-10-18`. |
| | `license` | text | License/reuse statement, with caveats where source rights are mixed or unknown. |
| | `verification_status` | text | Records the verification performed and material limitations. |

## Primary keys and relationships

- `deficiency_master.csv`: primary key `deficiency_id`.
- `symptom_master.csv`: primary key `symptom_id`.
- `deficiency_symptoms.csv`: logical composite key `(deficiency_id, symptom_id)`; both columns reference their respective master IDs. The current database uses an auto-increment `id` instead and does not enforce this pair as unique.
- `food_recommendations.csv`: logical candidate key `(deficiency_id, food_name)`; `deficiency_id` references the deficiency master. Confirm duplicate/case-colliding names before adding a unique constraint.
- `gene_associations.csv`, `protein_associations.csv`, `pathway_associations.csv`: primary key is the exported existing `association_id`; `deficiency_id` references the deficiency master.
- `dataset_sources.csv`: primary key `source_id`.

## Important limitations

The current database contains 48 symptom mappings with project-defined weights. This export preserves them for traceability; it does **not** assert that all are medically established. Several source pages could not be retrieved by the research tool, and the mapping file expressly marks pairwise support as unverified. The local gene, protein, pathway, and food records are also a snapshot, not a complete nutrient knowledge base. See `validation_report.md` before using the data.
